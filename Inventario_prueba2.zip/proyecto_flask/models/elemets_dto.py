class elemets_dto:
    def __init__(self,ID_elemento,referencia,nombres,cantidad,valor,estado,lugar, Observaciones,ID_categorias) -> None:
        self.ID_elemento = ID_elemento
        self.referencia = referencia
        self.nombres = nombres
        self.cantidad = cantidad
        self.valor= valor
        self.estado = estado
        self.lugar = lugar
        self.Observaciones = Observaciones
        self.ID_categorias = ID_categorias