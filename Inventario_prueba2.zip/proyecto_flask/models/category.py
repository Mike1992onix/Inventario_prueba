class category():

    def __init__(self,codigo,nombre,descripcion,observacion) -> None:
        self.codigo = codigo
        self.nombre = nombre
        self.descripcion = descripcion
        self.observacion = observacion

        